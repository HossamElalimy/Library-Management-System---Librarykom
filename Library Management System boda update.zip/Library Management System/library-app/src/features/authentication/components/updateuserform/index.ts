import { UpdateUserForm } from "./components/UpdateUserForm/UpdateUserForm";

export { UpdateUserForm };
