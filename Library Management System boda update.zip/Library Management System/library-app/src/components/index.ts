import { Modal } from "./Modal/Modal";

export{Modal};